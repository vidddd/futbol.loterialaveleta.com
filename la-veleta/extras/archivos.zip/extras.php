<?php include('templates/header_logged.php') ?>
<?php include('templates/latest_results.php') ?>
<?php include('templates/games.php') ?>
<?php include('extras/flc.php') ?>
<?php include('templates/footer.php') ?>